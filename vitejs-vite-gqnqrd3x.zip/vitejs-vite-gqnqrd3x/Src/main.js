import './style.css'
import { supabase } from './supabase.js'

const app = document.querySelector('#app')

const modules = [
  'Home',
  'Focus Zone',
  'Study With Me',
  'Study With Idols',
  'AI Study Companion',
  'Friends & Connections',
  'Creative Corner',
  'Settings'
]

app.innerHTML = `
  <div class="studora">
  <header class="topbar">
  <button class="menu-btn" id="menuBtn" aria-label="Open navigation">☰</button>

  <a class="brand" href="#" id="brandHome">
    <span class="brand-mark">S</span>
    <span>Studora</span>
  </a>

  <div class="top-actions">
    <span class="welcome-label">Your space to grow</span>

    <div class="theme-switcher" id="themeSwitcher">
      <button
        class="theme-toggle"
        id="themeToggle"
        type="button"
        aria-label="Choose theme"
        aria-expanded="false"
      >
        <span class="theme-toggle-icon">◐</span>
        <span class="theme-toggle-label">Theme</span>
        <span class="theme-chevron">⌄</span>
      </button>

      <div class="theme-dropdown" id="themeDropdown" hidden>
        <p class="theme-dropdown-heading">CHOOSE YOUR THEME</p>
        <div class="theme-options" id="quickThemeOptions"></div>
      </div>
    </div>

    <button
  class="profile-btn"
  id="profileBtn"
  type="button"
  aria-label="Open account"
>
  U
</button>

  </div>
</header>

<div class="account-overlay" id="accountOverlay" hidden>
  <section class="account-dialog">
    <button class="account-close" id="closeAccount" type="button">×</button>

    <p class="eyebrow">YOUR STUDORA ACCOUNT</p>
    <h2 id="authHeading">Welcome back.</h2>
    <p id="authDescription">Sign in to continue your journey.</p>

    <form id="authForm">
      <label for="authEmail">Email address</label>
      <input id="authEmail" type="email" required placeholder="you@example.com">

      <label for="authPassword">Password</label>
      <input id="authPassword" type="password" required minlength="6" placeholder="Enter your password">

      <button class="primary-btn" id="authSubmit" type="submit">
        Sign in
      </button>
    </form>

    <p id="authMessage" role="status"></p>

    <button id="authModeToggle" type="button">
      New to Studora? Create an account
    </button>

    <button id="signOutBtn" type="button" hidden>
      Sign out
    </button>
  </section>
</div>


    <div class="drawer-backdrop" id="backdrop"></div>

    <aside class="drawer" id="drawer">
      <div class="drawer-heading">
        <span class="brand-mark">S</span>
        <span>STUDORA</span>
        <button id="closeDrawer" aria-label="Close navigation">×</button>
      </div>
      <p class="nav-label">YOUR WORKSPACE</p>
      <nav id="navigation">
        ${modules.map((name, i) => `
          <button class="nav-item ${i === 0 ? 'active' : ''}"
            data-page="${name}">
            <span class="nav-icon">${['⌂','◷','▣','✧','✦','♧','✎','⚙'][i]}</span>
            <span>${name}</span>
          </button>
        `).join('')}
      </nav>
      <div class="drawer-footer">
        <span>STUDORA</span>
        <small>A little progress every day.</small>
      </div>
    </aside>

    <main class="main-content">
      <section class="hero-section">
        <div>
          <p class="eyebrow">YOUR PERSONAL STUDY SPACE</p>
          <h1 id="pageTitle">Welcome to Studora.</h1>
          <p id="pageDescription">
            Make room for focus, creativity and growth.
          </p>
        </div>
        <div class="hero-decoration">✧</div>
      </section>

      <section class="home-layout" id="homeLayout">

        <!-- LEFT SIDE: MAIN DASHBOARD -->
        <section class="dashboard-grid" id="dashboard">

          <article class="welcome-card">
            <p class="eyebrow">A FRESH START</p>
            <h2>Make today count.</h2>
            <p>Your goals don't need to be perfect. Just begin.</p>
            <button class="primary-btn" data-page="Focus Zone">
              Enter Focus Zone <span>→</span>
            </button>
          </article>

          <article class="quote-card">
            <span class="quote-symbol">“</span>
            <p>Small steps, taken consistently, create meaningful progress.</p>
            <span class="quote-caption">A STUDORA REMINDER</span>
          </article>

          <section class="quick-section">
            <div class="section-heading">
              <div>
                <p class="eyebrow">EXPLORE</p>
                <h2>Your workspace</h2>
              </div>
            </div>
            <div class="module-grid">
              ${modules.slice(1, 7).map((name, i) => `
                <button class="module-card" data-page="${name}">
                  <span class="module-icon">${['◷','▣','✧','✦','♧','✎'][i]}</span>
                  <span class="module-name">${name}</span>
                  <span class="module-arrow">↗</span>
                </button>
              `).join('')}
            </div>
          </section>

          <article class="task-card">
            <div class="section-heading">
              <div>
                <p class="eyebrow">YOUR DAY</p>
                <h2>Today's tasks</h2>
              </div>
              <span class="small-tag">MY LIST</span>
            </div>
            <form id="taskForm" class="task-form">
              <label class="sr-only" for="taskInput">New task</label>
              <input id="taskInput" placeholder="Add something to do..." maxlength="120" required>
              <button type="submit" aria-label="Add task">+</button>
            </form>
            <ul id="taskList" class="task-list">
              <li class="empty-task">Your task list is ready for you.</li>
            </ul>
          </article>

        </section>

        <!-- RIGHT SIDE: CALENDAR AND PLANNER -->
        <aside class="calendar-panel">

          <article class="calendar-card">
            <div class="section-heading calendar-heading">
              <div>
                <p class="eyebrow">YOUR PLANNER</p>
                <h2>Calendar</h2>
              </div>
              <div class="calendar-navigation">
                <button id="prevMonth" aria-label="Previous month">‹</button>
                <button id="nextMonth" aria-label="Next month">›</button>
              </div>
            </div>

            <h3 id="calendarMonth" class="calendar-month"></h3>

            <div class="calendar-weekdays">
              <span>Mon</span>
              <span>Tue</span>
              <span>Wed</span>
              <span>Thu</span>
              <span>Fri</span>
              <span>Sat</span>
              <span>Sun</span>
            </div>

            <div class="calendar-days" id="calendarDays"></div>

            <p class="selected-date-label" id="selectedDateLabel"></p>
          </article>

          <article class="schedule-card">
            <div class="section-heading">
              <div>
                <p class="eyebrow">PLAN YOUR DAY</p>
                <h2>Daily schedule</h2>
              </div>
              <span class="small-tag">SCHEDULE</span>
            </div>

            <form id="scheduleForm" class="calendar-form">
              <input
                id="scheduleTitle"
                type="text"
                placeholder="What are you planning?"
                maxlength="100"
                required
              >
              <div class="planner-form-row">
                <input id="scheduleTime" type="time" required aria-label="Activity time">
                <button type="submit" aria-label="Add schedule item">+</button>
              </div>
            </form>

            <ul class="schedule-list" id="scheduleList">
              <li class="planner-empty">No activities planned yet.</li>
            </ul>
          </article>

          <article class="reminders-card">
            <div class="section-heading">
              <div>
                <p class="eyebrow">DON'T FORGET</p>
                <h2>Reminders & Upcoming</h2>
              </div>
            </div>

            <form id="reminderForm" class="calendar-form">
              <input
                id="reminderTitle"
                type="text"
                placeholder="Add a reminder..."
                maxlength="120"
                required
              >
              <div class="planner-form-row">
                <input id="reminderDate" type="date" required aria-label="Reminder date">
                <button type="submit" aria-label="Add reminder">+</button>
              </div>
            </form>

            <ul class="reminder-list" id="reminderList">
              <li class="planner-empty">No reminders yet.</li>
            </ul>
          </article>

        </aside>
      </section>

      <section class="module-placeholder" id="modulePage" hidden>
  <div id="genericModule">
    <div class="placeholder-symbol">✧</div>
    <h2 id="moduleHeading"></h2>
    <p>This space is being prepared for your Studora experience.</p>
    <button class="primary-btn" id="backHome">← Back to Home</button>
  </div>

  <div class="settings-theme-panel" id="settingsThemePanel" hidden>
    <p class="eyebrow">MAKE IT YOURS</p>
    <h2>Themes & Customisation</h2>
    <p>Choose the colour atmosphere for your entire Studora workspace.</p>
    <div class="settings-theme-grid" id="settingsThemeOptions"></div>
  </div>
</section>

      <footer class="site-footer">
        <span>STUDORA</span>
        <span>Learn. Focus. Grow.</span>
      </footer>
    </main>
  </div>
`

// ------------------------------------
// NAVIGATION DRAWER
// ------------------------------------

const drawer = document.querySelector('#drawer')
const backdrop = document.querySelector('#backdrop')

function setDrawer(open) {
  drawer.classList.toggle('drawer-open', open)
  backdrop.classList.toggle('visible', open)
}

document.querySelector('#menuBtn').addEventListener('click', () => setDrawer(true))
document.querySelector('#closeDrawer').addEventListener('click', () => setDrawer(false))
backdrop.addEventListener('click', () => setDrawer(false))

function showPage(page) {
  const home = page === 'Home'
  const settings = page === 'Settings'

  document.querySelector('#pageTitle').textContent =
    home ? 'Welcome to Studora.' : page

  document.querySelector('#pageDescription').textContent =
    home ? 'Make room for focus, creativity and growth.' :
    settings ? 'Make Studora feel like your own space.' :
    `Welcome to your ${page} space.`

  document.querySelector('#homeLayout').hidden = !home
  document.querySelector('#modulePage').hidden = home

  document.querySelector('#genericModule').hidden = settings
  document.querySelector('#settingsThemePanel').hidden = !settings
  document.querySelector('#modulePage').classList.toggle('settings-mode', settings)

  document.querySelector('#moduleHeading').textContent = page

  document.querySelectorAll('.nav-item').forEach(button => {
    button.classList.toggle('active', button.dataset.page === page)
  })

  closeThemeDropdown()
  setDrawer(false)
}

document.querySelectorAll('[data-page]').forEach(button => {
  button.addEventListener('click', () => showPage(button.dataset.page))
})

document.querySelector('#brandHome').addEventListener('click', event => {
  event.preventDefault()
  showPage('Home')
})

document.querySelector('#backHome').addEventListener('click', () => showPage('Home'))

/* ------------------------------------
   STUDORA DATABASE HELPERS
------------------------------------ */

let currentUser = null

function requireSignIn() {
  if (currentUser) return true

  accountOverlay.hidden = false
  authMessage.textContent =
    'Please sign in to save your Studora data.'

  return false
}

function reportDatabaseError(error) {
  console.error('Studora database error:', error)
  alert(`Could not save your data: ${error.message}`)
}



// ------------------------------------
// TODAY'S TASKS — SUPABASE
// ------------------------------------

const taskForm = document.querySelector('#taskForm')
const taskInput = document.querySelector('#taskInput')
const taskList = document.querySelector('#taskList')

let tasks = []

function renderTasks() {
  taskList.innerHTML = ''

  if (!tasks.length) {
    taskList.innerHTML =
      '<li class="empty-task">Your task list is ready for you.</li>'
    return
  }

  tasks.forEach(task => {
    const li = document.createElement('li')
    li.className = 'task-item'

    const checkbox = document.createElement('input')
    checkbox.type = 'checkbox'
    checkbox.checked = task.completed

    checkbox.addEventListener('change', async () => {
      if (!currentUser) return

      const { error } = await supabase
        .from('tasks')
        .update({ completed: checkbox.checked })
        .eq('id', task.id)
        .eq('user_id', currentUser.id)

      if (error) {
        checkbox.checked = task.completed
        reportDatabaseError(error)
        return
      }

      task.completed = checkbox.checked
      renderTasks()
    })

    const title = document.createElement('span')
    title.textContent = task.title

    if (task.completed) {
      title.classList.add('task-completed')
    }

    const remove = document.createElement('button')
    remove.type = 'button'
    remove.className = 'planner-delete'
    remove.textContent = '×'
    remove.setAttribute('aria-label', 'Delete task')

    remove.addEventListener('click', async () => {
      if (!currentUser) return

      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', task.id)
        .eq('user_id', currentUser.id)

      if (error) {
        reportDatabaseError(error)
        return
      }

      tasks = tasks.filter(item => item.id !== task.id)
      renderTasks()
    })

    li.append(checkbox, title, remove)
    taskList.append(li)
  })
}

taskForm.addEventListener('submit', async event => {
  event.preventDefault()

  if (!requireSignIn()) return

  const title = taskInput.value.trim()
  if (!title) return

  const { data, error } = await supabase
    .from('tasks')
    .insert({
      user_id: currentUser.id,
      title,
      completed: false,
      priority: 'medium'
    })
    .select()
    .single()

  if (error) {
    reportDatabaseError(error)
    return
  }

  tasks.push(data)
  taskInput.value = ''
  renderTasks()
})

// ------------------------------------
// CALENDAR
// ------------------------------------

const today = new Date()

function dateKey(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function dateFromKey(key) {
  const [year, month, day] = key.split('-').map(Number)
  return new Date(year, month - 1, day)
}

function formatDate(date) {
  return date.toLocaleDateString(undefined, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  })
}

let selectedDate = dateKey(today)
let displayedMonth = new Date(today.getFullYear(), today.getMonth(), 1)

const scheduleByDate = new Map()
const reminders = []

const calendarDays = document.querySelector('#calendarDays')
const calendarMonth = document.querySelector('#calendarMonth')

function renderCalendar() {
  const year = displayedMonth.getFullYear()
  const month = displayedMonth.getMonth()

  calendarMonth.textContent = displayedMonth.toLocaleDateString(undefined, {
    month: 'long',
    year: 'numeric'
  })

  const firstDay = new Date(year, month, 1)
  const mondayOffset = (firstDay.getDay() + 6) % 7
  const gridStart = new Date(year, month, 1 - mondayOffset)

  calendarDays.innerHTML = ''

  for (let i = 0; i < 42; i++) {
    const date = new Date(gridStart)
    date.setDate(gridStart.getDate() + i)

    const key = dateKey(date)
    const button = document.createElement('button')

    button.type = 'button'
    button.className = 'calendar-day'
    button.textContent = date.getDate()
    button.dataset.date = key
    button.setAttribute('aria-label', formatDate(date))

    if (date.getMonth() !== month) {
      button.classList.add('outside-month')
    }

    if (key === dateKey(today)) {
      button.classList.add('today')
    }

    if (key === selectedDate) {
      button.classList.add('selected')
      button.setAttribute('aria-pressed', 'true')
    } else {
      button.setAttribute('aria-pressed', 'false')
    }

    calendarDays.append(button)
  }

  document.querySelector('#selectedDateLabel').textContent =
    `Selected: ${formatDate(dateFromKey(selectedDate))}`
}

calendarDays.addEventListener('click', event => {
  const button = event.target.closest('[data-date]')
  if (!button) return

  selectedDate = button.dataset.date

  const chosen = dateFromKey(selectedDate)
  displayedMonth = new Date(chosen.getFullYear(), chosen.getMonth(), 1)

  renderCalendar()
  renderSchedule()
})

document.querySelector('#prevMonth').addEventListener('click', () => {
  displayedMonth.setMonth(displayedMonth.getMonth() - 1)

  const newMonth = new Date(
    displayedMonth.getFullYear(),
    displayedMonth.getMonth(),
    1
  )

  displayedMonth = newMonth

  if (dateFromKey(selectedDate).getMonth() !== newMonth.getMonth() ||
      dateFromKey(selectedDate).getFullYear() !== newMonth.getFullYear()) {
    selectedDate = dateKey(newMonth)
  }

  renderCalendar()
  renderSchedule()
})

document.querySelector('#nextMonth').addEventListener('click', () => {
  displayedMonth.setMonth(displayedMonth.getMonth() + 1)

  const newMonth = new Date(
    displayedMonth.getFullYear(),
    displayedMonth.getMonth(),
    1
  )

  displayedMonth = newMonth

  if (dateFromKey(selectedDate).getMonth() !== newMonth.getMonth() ||
      dateFromKey(selectedDate).getFullYear() !== newMonth.getFullYear()) {
    selectedDate = dateKey(newMonth)
  }

  renderCalendar()
  renderSchedule()
})


/* ------------------------------------
   DAILY SCHEDULE — SUPABASE
------------------------------------ */

const scheduleForm = document.querySelector('#scheduleForm')
const scheduleTitle = document.querySelector('#scheduleTitle')
const scheduleTime = document.querySelector('#scheduleTime')
const scheduleList = document.querySelector('#scheduleList')

async function renderSchedule() {
  scheduleList.innerHTML = ''

  const items = scheduleByDate.get(selectedDate) || []

  if (!items.length) {
    scheduleList.innerHTML =
      '<li class="planner-empty">No activities planned for this date.</li>'
    return
  }

  const sortedItems = [...items].sort((a, b) =>
    (a.time || '').localeCompare(b.time || '')
  )

  sortedItems.forEach(item => {
    const li = document.createElement('li')
    li.className = 'schedule-item'

    const time = document.createElement('span')
    time.className = 'schedule-time'
    time.textContent = item.time || ''

    const title = document.createElement('span')
    title.className = 'schedule-title'
    title.textContent = item.title

    const remove = document.createElement('button')
    remove.type = 'button'
    remove.className = 'planner-delete'
    remove.textContent = '×'
    remove.setAttribute('aria-label', 'Delete schedule item')

    remove.addEventListener('click', async () => {
      const { error } = await supabase
        .from('schedules')
        .delete()
        .eq('id', item.id)
        .eq('user_id', currentUser.id)

      if (error) {
        reportDatabaseError(error)
        return
      }

      const current = scheduleByDate.get(selectedDate) || []
      scheduleByDate.set(
        selectedDate,
        current.filter(entry => entry.id !== item.id)
      )

      renderSchedule()
    })

    li.append(time, title, remove)
    scheduleList.append(li)
  })
}

scheduleForm.addEventListener('submit', async event => {
  event.preventDefault()

  if (!requireSignIn()) return

  const title = scheduleTitle.value.trim()
  const time = scheduleTime.value

  if (!title || !time) return

  const { data, error } = await supabase
    .from('schedules')
    .insert({
      user_id: currentUser.id,
      title,
      schedule_date: selectedDate,
      start_time: time
    })
    .select()
    .single()

  if (error) {
    reportDatabaseError(error)
    return
  }

  const items = scheduleByDate.get(selectedDate) || []

  items.push({
    id: data.id,
    title: data.title,
    time: data.start_time
  })

  scheduleByDate.set(selectedDate, items)

  scheduleTitle.value = ''
  scheduleTime.value = ''

  renderSchedule()
})


/* ------------------------------------
   REMINDERS — SUPABASE
------------------------------------ */

const reminderForm = document.querySelector('#reminderForm')
const reminderTitle = document.querySelector('#reminderTitle')
const reminderDate = document.querySelector('#reminderDate')
const reminderList = document.querySelector('#reminderList')

reminderDate.value = selectedDate

function renderReminders() {
  reminderList.innerHTML = ''

  const sorted = [...reminders].sort((a, b) =>
    a.date.localeCompare(b.date)
  )

  if (!sorted.length) {
    reminderList.innerHTML =
      '<li class="planner-empty">No reminders yet. Add one above.</li>'
    return
  }

  sorted.forEach(reminder => {
    const li = document.createElement('li')
    li.className = 'reminder-item'

    if (reminder.completed) {
      li.classList.add('reminder-completed')
    }

    const check = document.createElement('input')
    check.type = 'checkbox'
    check.checked = reminder.completed
    check.setAttribute('aria-label', 'Mark reminder complete')

    check.addEventListener('change', async () => {
      const { error } = await supabase
        .from('reminders')
        .update({ is_completed: check.checked })
        .eq('id', reminder.id)
        .eq('user_id', currentUser.id)

      if (error) {
        check.checked = reminder.completed
        reportDatabaseError(error)
        return
      }

      reminder.completed = check.checked
      renderReminders()
    })

    const content = document.createElement('div')
    content.className = 'reminder-content'

    const title = document.createElement('span')
    title.className = 'reminder-title'
    title.textContent = reminder.title

    const date = document.createElement('small')
    date.textContent = dateFromKey(reminder.date).toLocaleDateString(
      undefined,
      { day: 'numeric', month: 'short', year: 'numeric' }
    )

    content.append(title, date)

    const remove = document.createElement('button')
    remove.type = 'button'
    remove.className = 'planner-delete'
    remove.textContent = '×'
    remove.setAttribute('aria-label', 'Delete reminder')

    remove.addEventListener('click', async () => {
      const { error } = await supabase
        .from('reminders')
        .delete()
        .eq('id', reminder.id)
        .eq('user_id', currentUser.id)

      if (error) {
        reportDatabaseError(error)
        return
      }

      const index = reminders.findIndex(
        item => item.id === reminder.id
      )

      if (index !== -1) reminders.splice(index, 1)

      renderReminders()
    })

    li.append(check, content, remove)
    reminderList.append(li)
  })
}

reminderForm.addEventListener('submit', async event => {
  event.preventDefault()

  if (!requireSignIn()) return

  const title = reminderTitle.value.trim()
  const date = reminderDate.value

  if (!title || !date) return

  const { data, error } = await supabase
    .from('reminders')
    .insert({
      user_id: currentUser.id,
      title,
      reminder_date: date,
      is_completed: false
    })
    .select()
    .single()

  if (error) {
    reportDatabaseError(error)
    return
  }

  reminders.push({
    id: data.id,
    title: data.title,
    date: data.reminder_date,
    completed: data.is_completed
  })

  reminderTitle.value = ''
  reminderDate.value = selectedDate

  renderReminders()
})
// ------------------------------------
// GLOBAL THEME SWITCHER
// ------------------------------------

const themes = [
  { id: 'royal-burgundy', name: 'Royal Burgundy', color: '#641c35', accent: '#d5b477' },
  { id: 'light', name: 'Light', color: '#eee8df', accent: '#98703d' },
  { id: 'dark', name: 'Dark', color: '#252525', accent: '#c6b58a' },
  { id: 'sepia', name: 'Sepia', color: '#59432f', accent: '#d7b985' },
  { id: 'dracula', name: 'Dracula', color: '#282a36', accent: '#bd93f9' },
  { id: 'midnight', name: 'Midnight', color: '#101b32', accent: '#8ca9ed' },
  { id: 'amoled', name: 'AMOLED', color: '#000000', accent: '#d4b36e' },
  { id: 'nord', name: 'Nord', color: '#3b4252', accent: '#88c0d0' },
  { id: 'solarized', name: 'Solarized', color: '#002b36', accent: '#b58900' },
  { id: 'forest', name: 'Forest', color: '#203b30', accent: '#a7bd83' },
  { id: 'ink', name: 'Ink', color: '#24212a', accent: '#c6b8d9' }
]

const validThemeIds = themes.map(theme => theme.id)

let activeTheme = 'royal-burgundy'

try {
  const savedTheme = localStorage.getItem('studora-theme')
  if (validThemeIds.includes(savedTheme)) {
    activeTheme = savedTheme
  }
} catch (error) {
  console.warn('Theme preference could not be loaded.')
}

function applyTheme(themeId) {
  if (!validThemeIds.includes(themeId)) return

  activeTheme = themeId
  document.documentElement.dataset.theme = themeId

  try {
    localStorage.setItem('studora-theme', themeId)
  } catch (error) {
    console.warn('Theme preference could not be saved.')
  }

  document.querySelectorAll('[data-theme-choice]').forEach(button => {
    const selected = button.dataset.themeChoice === themeId
    button.classList.toggle('selected-theme', selected)
    button.setAttribute('aria-pressed', String(selected))
  })
}

function createThemeOptions(container) {
  container.innerHTML = ''

  themes.forEach(theme => {
    const button = document.createElement('button')
    button.type = 'button'
    button.className = 'theme-option'
    button.dataset.themeChoice = theme.id
    button.setAttribute('aria-label', `Apply ${theme.name} theme`)

    const swatch = document.createElement('span')
    swatch.className = 'theme-swatch'
    swatch.style.setProperty('--swatch-color', theme.color)
    swatch.style.setProperty('--swatch-accent', theme.accent)

    const name = document.createElement('span')
    name.className = 'theme-option-name'
    name.textContent = theme.name

    const check = document.createElement('span')
    check.className = 'theme-option-check'
    check.textContent = '✓'

    button.append(swatch, name, check)

    button.addEventListener('click', () => {
      applyTheme(theme.id)
      closeThemeDropdown()
    })

    container.append(button)
  })
}

const themeToggle = document.querySelector('#themeToggle')
const themeDropdown = document.querySelector('#themeDropdown')

function closeThemeDropdown() {
  if (!themeDropdown || !themeToggle) return

  themeDropdown.hidden = true
  themeToggle.setAttribute('aria-expanded', 'false')
}

themeToggle.addEventListener('click', event => {
  event.stopPropagation()

  const opening = themeDropdown.hidden
  themeDropdown.hidden = !opening
  themeToggle.setAttribute('aria-expanded', String(opening))
})

document.addEventListener('click', event => {
  if (!event.target.closest('#themeSwitcher')) {
    closeThemeDropdown()
  }
})

document.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    closeThemeDropdown()
  }
})

createThemeOptions(document.querySelector('#quickThemeOptions'))
createThemeOptions(document.querySelector('#settingsThemeOptions'))

applyTheme(activeTheme)

/* ------------------------------------
   STUDORA ACCOUNT & AUTHENTICATION
------------------------------------ */

const profileBtn = document.querySelector('#profileBtn')
const accountOverlay = document.querySelector('#accountOverlay')
const closeAccount = document.querySelector('#closeAccount')
const authForm = document.querySelector('#authForm')
const authEmail = document.querySelector('#authEmail')
const authPassword = document.querySelector('#authPassword')
const authHeading = document.querySelector('#authHeading')
const authDescription = document.querySelector('#authDescription')
const authSubmit = document.querySelector('#authSubmit')
const authMessage = document.querySelector('#authMessage')
const authModeToggle = document.querySelector('#authModeToggle')
const signOutBtn = document.querySelector('#signOutBtn')

let isSignUpMode = false

function openAccount() {
  accountOverlay.hidden = false
}

function closeAccountDialog() {
  accountOverlay.hidden = true
  authMessage.textContent = ''
}

function updateAccountUI(user) {
  if (user) {
    profileBtn.textContent = (
      user.email?.charAt(0) || 'U'
    ).toUpperCase()

    authHeading.textContent = 'Your account'
    authDescription.textContent = user.email || 'Signed in'
    authForm.hidden = true
    authModeToggle.hidden = true
    signOutBtn.hidden = false
  } else {
    profileBtn.textContent = 'U'

    authHeading.textContent = 'Welcome back.'
    authDescription.textContent = 'Sign in to continue your journey.'
    authForm.hidden = false
    authModeToggle.hidden = false
    signOutBtn.hidden = true
    authSubmit.textContent = isSignUpMode
      ? 'Create account'
      : 'Sign in'
  }
}

profileBtn.addEventListener('click', openAccount)
closeAccount.addEventListener('click', closeAccountDialog)

accountOverlay.addEventListener('click', event => {
  if (event.target === accountOverlay) {
    closeAccountDialog()
  }
})

authModeToggle.addEventListener('click', () => {
  isSignUpMode = !isSignUpMode

  authHeading.textContent = isSignUpMode
    ? 'Create your account.'
    : 'Welcome back.'

  authDescription.textContent = isSignUpMode
    ? 'Join your personal Studora workspace.'
    : 'Sign in to continue your journey.'

  authSubmit.textContent = isSignUpMode
    ? 'Create account'
    : 'Sign in'

  authModeToggle.textContent = isSignUpMode
    ? 'Already have an account? Sign in'
    : 'New to Studora? Create an account'

  authMessage.textContent = ''
})

authForm.addEventListener('submit', async event => {
  event.preventDefault()

  const email = authEmail.value.trim()
  const password = authPassword.value

  authSubmit.disabled = true
  authMessage.textContent = 'Please wait...'

  try {
    let result

    if (isSignUpMode) {
      result = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: window.location.origin
        }
      })
      
    } else {
      result = await supabase.auth.signInWithPassword({
        email,
        password
      })
    }

    if (result.error) throw result.error

    if (isSignUpMode && !result.data.session) {
      authMessage.textContent =
        'Account created! Check your email to confirm your address.'
      return
    }

    authMessage.textContent = 'Successfully signed in!'
    updateAccountUI(result.data.user)
  } catch (error) {
    authMessage.textContent = error.message
  } finally {
    authSubmit.disabled = false
  }
})

signOutBtn.addEventListener('click', async () => {
  signOutBtn.disabled = true

  try {
    const { error } = await supabase.auth.signOut()

    if (error) throw error

    updateAccountUI(null)
    authMessage.textContent = 'You have signed out.'
  } catch (error) {
    authMessage.textContent = error.message
  } finally {
    signOutBtn.disabled = false
  }
})


/* ------------------------------------
   LOAD USER DATA FROM SUPABASE
------------------------------------ */

async function loadDashboardData() {
  if (!currentUser) return

  const userId = currentUser.id

  const [taskResult, scheduleResult, reminderResult] =
    await Promise.all([
      supabase
        .from('tasks')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: true }),

      supabase
        .from('schedules')
        .select('*')
        .eq('user_id', userId)
        .order('start_time', { ascending: true }),

      supabase
        .from('reminders')
        .select('*')
        .eq('user_id', userId)
        .order('reminder_date', { ascending: true })
    ])

  if (taskResult.error) {
    reportDatabaseError(taskResult.error)
    return
  }

  if (scheduleResult.error) {
    reportDatabaseError(scheduleResult.error)
    return
  }

  if (reminderResult.error) {
    reportDatabaseError(reminderResult.error)
    return
  }

  tasks = taskResult.data || []

  scheduleByDate.clear()

  scheduleResult.data.forEach(item => {
    const date = item.schedule_date

    if (!scheduleByDate.has(date)) {
      scheduleByDate.set(date, [])
    }

    scheduleByDate.get(date).push({
      id: item.id,
      title: item.title,
      time: item.start_time || ''
    })
  })

  reminders.splice(0, reminders.length)

  reminderResult.data.forEach(item => {
    reminders.push({
      id: item.id,
      title: item.title,
      date: item.reminder_date,
      completed: item.is_completed
    })
  })

  renderTasks()
  renderSchedule()
  renderReminders()
}

supabase.auth.onAuthStateChange((event, session) => {
  currentUser = session?.user ?? null
  updateAccountUI(currentUser)

  if (event === 'SIGNED_IN') {
    loadDashboardData()
  }

  if (event === 'SIGNED_OUT') {
    tasks = []
    scheduleByDate.clear()
    reminders.splice(0, reminders.length)

    renderTasks()
    renderSchedule()
    renderReminders()
  }
})


async function initialiseAccount() {
  const { data, error } = await supabase.auth.getSession()

  if (error) {
    console.error('Could not load account:', error.message)
    return
  }

  currentUser = data.session?.user ?? null
  updateAccountUI(currentUser)

  if (currentUser) {
    await loadDashboardData()
  }
}

initialiseAccount()
